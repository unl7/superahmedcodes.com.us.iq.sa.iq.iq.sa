const { MessageEmbed } = require ('discord.js');

module.exports = {
    name: 'tax',
    description: "tax ",
    cooldown: 3000,
    execute(client, message, args) {

 let args2 = parseInt(args)
  let tax = Math.floor(args2 * (20) / (19) + (1))
  let tax2 = Math.floor(args2 * (20) / (19) + (1)-(args2))
  let tax3 = Math.floor(tax2 * (20) / (19) + (1))
  let tax4 = Math.floor(tax2 + tax3 + args2)
   
  const embed1 = new MessageEmbed()
  .setTitle(`**<a:re:924823069661491221> عذراً**`)
  .setColor("#f04747")
  .setDescription(`**يجب أن يكون رقمًا**`)
  if (!args2) return message.channel.send({content: "",embeds: [embed1]});
  const embed2 = new MessageEmbed()
  .setTitle(`**<a:re:924823069661491221> عذراً**`)
  .setColor("#f04747")
  .setDescription(`**يجب أن يكون رقمًا**`)
  if (isNaN(args2)) return message.channel.send({content: "", embeds: [embed2]});
  const embed3 = new MessageEmbed()
  .setTitle(`**<a:re:924823069661491221> عذراً**`)
  .setColor("#f04747")
  .setDescription(`**يجب أن يكون الرقم أكبر 1**`)
  if (args2 < 1) return message.channel.send({content: "",embeds: [embed3]});
  const embed4 = new MessageEmbed()
  .setTitle(`**<:Fa_Statics:967081080731627523> التكلفة النهائية هي:**`)
  .setColor("#39dadf")
  .setDescription(`1`)
  if (args2 == 1) return message.channel.send({content: "",embeds: [embed4]});

message.reply(`**- المبلغ : ${args} **
**- المبلغ بالضرائب : ${tax} **
**- المبلغ بدون الوسيط : ${tax} **
**- المبلغ مع الوسيط : ${tax4} **`)
    }
}