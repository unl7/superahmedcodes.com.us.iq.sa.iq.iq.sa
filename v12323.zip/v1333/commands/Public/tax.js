const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'tax33',
    description: "tax calculator",
    cooldown: 5000,
    execute(client, message, args) {
        let num = args[0];
        var tax = 5.3;
        var numerr = Math.floor(num);
        if (numerr < 0 || numerr == NaN || !numerr) {
            return message.reply({ content: "**يجب ان يكون الرقم صحيح**", ephemeral: true });
        }
        var taxval = Math.floor(numerr * (tax / 100));
        var amount = Math.floor(numerr - taxval);
        var amountfinal = Math.floor(numerr + taxval);
        let taxemb = new MessageEmbed()
            .setTitle("ضريبة برو بوت")
            .setColor('PURPLE')
            .setThumbnail(client.user.displayAvatarURL())
            .addField(`المبلغ:`, ` \`\`\`\ ${numerr} \`\`\`\ `)
            .addField(`النسبه الي يسحبها البوت:`, ` \`\`\`\ ${tax}% \`\`\`\ `)
            .addField(`المبلغ الي يسحبه البوت:`, ` \`\`\`\ ${taxval} \`\`\`\ `)
            .addField(`المبلغ مع الضريبة:`, ` \`\`\`\ ${amount} \`\`\`\ `)
            .addField(`كم لازم تحول عشان يوصل المبلغ بالضبط:`, ` \`\`\`\ ${amountfinal} \`\`\`\ `)
            .setTimestamp()
            .setThumbnail("https://images-ext-2.discordapp.net/external/9YypUckVSLonoKmFV5L2Sn9xLV00Bk_qn2xrgzw6v0Q/%3Fsize%3D1024/https/cdn.discordapp.com/avatars/282859044593598464/156a0d2872579f1ffcaa5d2127239bfd.png?width=270&height=270")

        message.reply({ embeds: [taxemb] });
    }
} 

