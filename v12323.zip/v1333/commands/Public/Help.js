const {  MessageSelectMenu, MessageActionRow,MessageEmbed } = require('discord.js');


module.exports = {
    name: 'help',
    aliases: 'h',

  async execute(client, interaction) {
const prefix = '+'
        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('Select')
                    .setPlaceholder('Click Here ')
                    .addOptions([
                        {
                            label:
'Auto line',
                            description: 'Line Commands',
                            value: 'first_option',
                          emoji:
  '💠',                        
                        },
                        {
                            label: 'soon..❔ ',
                            description: 'soon..❔',
                            value: 
'second_option',
                            emoji:
 '❔',                             
        

                        },
                    ]),
            );

let embed5 = new MessageEmbed()


  .setDescription('**لإظهار قائمة الاوامر اضغط على __click here__**')

.setColor('BLUE')
.setTimestamp()
.setFooter({text: 'System Commands help menu'});
    
        await interaction.channel.send({ embeds: [embed5], components: [row] });
   

client.on("interactionCreate" , interaction => {
  if(!interaction.isSelectMenu()) return;
  if(interaction.values == "first_option") {
    interaction.reply({embeds: [embed1] , ephemeral : true})

  }
  if(interaction.values == "second_option") {
    interaction.reply({content:"قريبآ عليك الأنتظار.." , ephemeral : true})


  }
});


//help embeds
let embed1 = new MessageEmbed()

.addField(`** ❃ | ${prefix} line | ${prefix} ln **`, `**\` لوضع الخط \`**`)
.addField(`** ❃  | ${prefix} addroom | ${prefix} ar**`, `**\` لاضافة روم الي الخط التلقائي \`**`)
.addField(`** ❃ | ${prefix }cleardb| ${prefix} cd**`,`**\` لمسح جميع البيانات الخاصة بالسيرفر \`**`)
.addField(`** ❃  | ${prefix} setline | ${prefix} sl**`,`**\` لتحديد الخط \`**`)
.addField(`** ❃ | ${prefix} setreaction | ${prefix} sr**`,`**\` لتحديد الريأكشن \`**`)
.setFooter({text: 'line  Commands help menu'});



    }
}