const { Client, Intents, Collection, Interaction } = require('discord.js');

const client = new Client({
    intents: [
        Intents.FLAGS.GUILDS,
        Intents.FLAGS.GUILD_MESSAGES,
        Intents.FLAGS.GUILD_MEMBERS,
    ]
});
module.exports = client; 

client.commands = new Collection();
client.events = new Collection();
client.aliases = new Collection();
client.SlashCommands = new Collection();

['commands', 'events'].forEach(handler => {
    require(`./handlers/${handler}`)(client);
})

client.login(process.env.token); 

