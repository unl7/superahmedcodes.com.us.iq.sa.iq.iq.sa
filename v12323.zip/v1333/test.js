module.exports = {
    name: 'test',
   aliases: ''//اختصار 
   async execute(client, message, args) {

        // احذف السطر هذا وحط الكود حقك

    }
}